import React, { useState, useEffect } from 'react';

// --- Helper Functions to interact with localStorage ---

// Function to get all hospitals from localStorage
const getHospitals = () => {
    return JSON.parse(localStorage.getItem('hospitals')) || [];
};

// Function to save all hospitals to localStorage
const saveHospitals = (hospitals) => {
    localStorage.setItem('hospitals', JSON.stringify(hospitals));
};

// --- AdminDashboard Component ---

export default function AdminDashboard() {
    // State to hold the admin's hospital data
    const [myHospital, setMyHospital] = useState(null);
    // State for the hospital registration form inputs
    const [hospitalName, setHospitalName] = useState('');
    const [hospitalLocation, setHospitalLocation] = useState('');
    // State for the new department form input
    const [departmentName, setDepartmentName] = useState('');
    // State for displaying messages to the user
    const [message, setMessage] = useState('');

    // This effect runs when the component loads to find the admin's hospital
    useEffect(() => {
        const currentUser = JSON.parse(localStorage.getItem('user'));
        const allHospitals = getHospitals();
        const adminHospital = allHospitals.find(h => h.adminId === currentUser.email);

        if (adminHospital) {
            setMyHospital(adminHospital);
        }
    }, []);

    // --- Event Handlers ---

    // Handles the submission of the hospital registration form
    const handleCreateHospital = (e) => {
        e.preventDefault();
        const currentUser = JSON.parse(localStorage.getItem('user'));
        const allHospitals = getHospitals();

        // Create a new hospital object
        const newHospital = {
            id: `hosp_${Date.now()}`, // Simple unique ID
            name: hospitalName,
            location: hospitalLocation,
            adminId: currentUser.email,
            departments: []
        };

        // Add the new hospital and save
        saveHospitals([...allHospitals, newHospital]);

        // Update the state to show the new hospital immediately
        setMyHospital(newHospital);
    };

    // Handles adding a new department
    const handleAddDepartment = (e) => {
        e.preventDefault();
        setMessage('');

        if (!departmentName.trim()) {
            setMessage('Department name cannot be empty.');
            return;
        }

        const allHospitals = getHospitals();
        // Find the index of the current admin's hospital
        const hospitalIndex = allHospitals.findIndex(h => h.id === myHospital.id);

        if (hospitalIndex === -1) {
            setMessage('Error: Could not find your hospital.');
            return;
        }

        const updatedHospital = { ...allHospitals[hospitalIndex] };

        // Check if department already exists (case-insensitive)
        if (updatedHospital.departments.some(dep => dep.toLowerCase() === departmentName.toLowerCase())) {
            setMessage('This department already exists.');
            return;
        }

        // Add the new department
        updatedHospital.departments.push(departmentName.trim());

        // Update the hospital in the main array
        allHospitals[hospitalIndex] = updatedHospital;
        saveHospitals(allHospitals);

        // Update the state to re-render the component with the new department
        setMyHospital(updatedHospital);
        setDepartmentName(''); // Clear the input field
    };


    // --- Render Logic ---

    // If the admin has not yet created a hospital, show the registration form
    if (!myHospital) {
        return (
            <div className="dashboard-container">
                <h1>Register Your Hospital</h1>
                <p>You have not registered a hospital yet. Please enter the details below.</p>
                <form onSubmit={handleCreateHospital} className="dashboard-form">
                    <div className="form-group">
                        <label>Hospital Name</label>
                        <input
                            type="text"
                            value={hospitalName}
                            onChange={(e) => setHospitalName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Location</label>
                        <input
                            type="text"
                            value={hospitalLocation}
                            onChange={(e) => setHospitalLocation(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit">Create Hospital</button>
                </form>
            </div>
        );
    }

    // If the hospital exists, show its details and the department management section
    return (
        <div className="dashboard-container">
            <h1>{myHospital.name}</h1>
            <p className="hospital-location">{myHospital.location}</p>

            <hr className="divider" />

            <h2>Manage Departments</h2>
            <div className="departments-section">
                <div className="department-list">
                    <h3>Existing Departments</h3>
                    {myHospital.departments.length > 0 ? (
                        <ul>
                            {myHospital.departments.map((dept, index) => (
                                <li key={index}>{dept}</li>
                            ))}
                        </ul>
                    ) : (
                        <p>No departments have been added yet.</p>
                    )}
                </div>

                <div className="add-department-form">
                    <h3>Add New Department</h3>
                    <form onSubmit={handleAddDepartment}>
                        <div className="form-group">
                            <label>Department Name</label>
                            <input
                                type="text"
                                value={departmentName}
                                onChange={(e) => setDepartmentName(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit">Add Department</button>
                        {message && <p className="message">{message}</p>}
                    </form>
                </div>
            </div>
        </div>
    );
}
