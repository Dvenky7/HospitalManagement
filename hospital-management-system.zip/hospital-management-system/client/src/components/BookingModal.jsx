import React from 'react';

// This modal component pops up to confirm an appointment booking.
export default function BookingModal({ slot, doctor, association, onConfirm, onCancel }) {
    // If there's no selected slot, don't render the modal
    if (!slot) {
        return null;
    }

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <h2>Confirm Appointment</h2>
                <p>You are about to book an appointment with:</p>
                <div className="booking-details">
                    <p><strong>Doctor:</strong> Dr. {doctor.fullName}</p>
                    <p><strong>Hospital:</strong> {association.hospitalName}</p>
                    <p><strong>Date & Time:</strong> {new Date(slot.startTime).toLocaleString()}</p>
                    <p><strong>Consultation Fee:</strong> ${association.fee}</p>
                </div>
                <div className="modal-actions">
                    <button onClick={onConfirm} className="confirm-btn">Confirm Booking</button>
                    <button onClick={onCancel} className="cancel-btn">Cancel</button>
                </div>
            </div>
        </div>
    );
}
