import React, { useState, useEffect } from 'react';

// --- Helper functions to manage data in localStorage ---
const getHospitals = () => JSON.parse(localStorage.getItem('hospitals')) || [];
const getAssociations = () => JSON.parse(localStorage.getItem('doctorAssociations')) || [];
const saveAssociations = (associations) => localStorage.setItem('doctorAssociations', JSON.stringify(associations));
const getAvailability = () => JSON.parse(localStorage.getItem('availabilitySlots')) || [];
const saveAvailability = (slots) => localStorage.setItem('availabilitySlots', JSON.stringify(slots));


export default function DoctorDashboard() {
    const [currentUser, setCurrentUser] = useState(null);
    const [hospitals, setHospitals] = useState([]);
    const [myAssociations, setMyAssociations] = useState([]);
    const [myAvailability, setMyAvailability] = useState([]);
    const [message, setMessage] = useState('');

    // Form state
    const [selectedHospital, setSelectedHospital] = useState('');
    const [consultationFee, setConsultationFee] = useState('');
    const [slotDate, setSlotDate] = useState('');
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');

    useEffect(() => {
        // Get the simplified user object from login
        const loggedInUser = JSON.parse(localStorage.getItem('user'));
        if (!loggedInUser) return; // Exit if no user is logged in

        // Get the full list of all users
        const allUsers = JSON.parse(localStorage.getItem('users')) || [];

        // Find the complete doctor profile from the main users list
        const doctorProfile = allUsers.find(u => u.email === loggedInUser.email && u.role === 'DOCTOR');

        // Only proceed if the full profile was found
        if (doctorProfile) {
            setCurrentUser(doctorProfile);

            // Load associations and availability based on the found profile
            const allAssociations = getAssociations();
            const doctorAssociations = allAssociations.filter(a => a.doctorId === doctorProfile.email);
            setMyAssociations(doctorAssociations);

            const allSlots = getAvailability();
            const doctorSlots = allSlots.filter(s => s.doctorId === doctorProfile.email);
            setMyAvailability(doctorSlots);
        }

        // Load hospitals regardless
        setHospitals(getHospitals());
    }, []);

    const handleAssociate = (e) => {
        e.preventDefault();
        setMessage('');

        const hospitalToJoin = hospitals.find(h => h.id === selectedHospital);
        if (!hospitalToJoin) {
            setMessage('Please select a valid hospital.');
            return;
        }

        // Check if doctor's specialization matches any hospital department
        const hasMatchingDept = (currentUser.specializations || []).some(spec =>
            hospitalToJoin.departments.map(d => d.toLowerCase()).includes(spec.toLowerCase())
        );

        if (!hasMatchingDept) {
            setMessage(`Your specializations do not match any department at ${hospitalToJoin.name}.`);
            return;
        }

        const allAssociations = getAssociations();
        const newAssociation = {
            id: `assoc_${Date.now()}`,
            doctorId: currentUser.email,
            hospitalId: hospitalToJoin.id,
            hospitalName: hospitalToJoin.name,
            fee: consultationFee,
        };

        const updatedAssociations = [...allAssociations, newAssociation];
        saveAssociations(updatedAssociations);
        setMyAssociations(updatedAssociations.filter(a => a.doctorId === currentUser.email));
        setMessage(`Successfully associated with ${hospitalToJoin.name}.`);
    };

    const handleAddSlot = (e) => {
        e.preventDefault();
        setMessage('');

        const allSlots = getAvailability();
        const newStart = new Date(`${slotDate}T${startTime}`);
        const newEnd = new Date(`${slotDate}T${endTime}`);

        // Crucially, check for conflicting time slots across all hospitals for this doctor
        const hasConflict = allSlots.filter(s => s.doctorId === currentUser.email).some(slot => {
            const existingStart = new Date(slot.startTime);
            const existingEnd = new Date(slot.endTime);
            // Overlap condition: (StartA < EndB) and (EndA > StartB)
            return newStart < existingEnd && newEnd > existingStart;
        });

        if (hasConflict) {
            setMessage('This time slot conflicts with an existing one.');
            return;
        }

        const newSlot = {
            id: `slot_${Date.now()}`,
            doctorId: currentUser.email,
            startTime: newStart.toISOString(),
            endTime: newEnd.toISOString(),
            isBooked: false,
        };

        const updatedSlots = [...allSlots, newSlot];
        saveAvailability(updatedSlots);
        setMyAvailability(updatedSlots.filter(s => s.doctorId === currentUser.email));
        setMessage('Availability slot added successfully.');
    };

    // If the doctor's full profile hasn't loaded yet, show a loading/error message.
    // This prevents the component from crashing.
    if (!currentUser) {
        return (
            <div className="dashboard-container">
                <h1>Doctor Dashboard</h1>
                <p>Loading doctor profile...</p>
                <p className="message">If this message persists, your profile may be incomplete. Please log out and register again as a Doctor to create a complete profile.</p>
            </div>
        );
    }

    // Once currentUser is loaded, render the full dashboard
    return (
        <div className="dashboard-container">
            <h1>Doctor Dashboard</h1>
            <p>Welcome, Dr. {currentUser.fullName || 'N/A'}!</p>

            <div className="doctor-profile-details">
                <strong>Qualifications:</strong> {currentUser.qualifications || 'N/A'} |
                <strong> Experience:</strong> {currentUser.yearsOfExperience || '0'} years |
                <strong> Specializations:</strong> {(currentUser.specializations || []).join(', ') || 'N/A'}
            </div>

            <hr className="divider" />

            <div className="doctor-management-section">
                {/* --- Associate with Hospital --- */}
                <div className="management-card">
                    <h2>Associate with a Hospital</h2>
                    <form onSubmit={handleAssociate}>
                        <div className="form-group">
                            <label>Select Hospital</label>
                            <select value={selectedHospital} onChange={e => setSelectedHospital(e.target.value)} required>
                                <option value="">-- Choose a hospital --</option>
                                {hospitals.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}
                            </select>
                        </div>
                        <div className="form-group">
                            <label>Consultation Fee (per visit)</label>
                            <input type="number" value={consultationFee} onChange={e => setConsultationFee(e.target.value)} required />
                        </div>
                        <button type="submit">Associate</button>
                    </form>
                </div>

                {/* --- Add Availability --- */}
                <div className="management-card">
                    <h2>Add Availability Slot</h2>
                    <form onSubmit={handleAddSlot}>
                        <div className="form-group">
                            <label>Date</label>
                            <input type="date" value={slotDate} onChange={e => setSlotDate(e.target.value)} required />
                        </div>
                        <div className="form-group">
                            <label>Start Time</label>
                            <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} required />
                        </div>
                        <div className="form-group">
                            <label>End Time</label>
                            <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} required />
                        </div>
                        <button type="submit">Add Slot</button>
                    </form>
                </div>
            </div>

            {message && <p className="message">{message}</p>}

            <hr className="divider" />

            {/* --- View Associations & Availability --- */}
            <div className="doctor-view-section">
                <div className="view-card">
                    <h3>My Hospital Associations</h3>
                    {myAssociations.length > 0 ? (
                        <ul>{myAssociations.map(a => <li key={a.id}>{a.hospitalName} (Fee: ${a.fee})</li>)}</ul>
                    ) : <p>You are not associated with any hospitals yet.</p>}
                </div>
                <div className="view-card">
                    <h3>My Upcoming Availability</h3>
                    {myAvailability.length > 0 ? (
                        <ul>{myAvailability.map(s => <li key={s.id}>{new Date(s.startTime).toLocaleString()} - {new Date(s.endTime).toLocaleTimeString()}</li>)}</ul>
                    ) : <p>You have not added any availability slots.</p>}
                </div>
            </div>
        </div>
    );
}
