import React from 'react';
import { Navigate } from 'react-router-dom';
import PatientDashboard from '../components/PatientDashboard';
import DoctorDashboard from '../components/DoctorDashboard';
import AdminDashboard from '../components/AdminDashboard';

export default function DashboardPage() {
    const user = JSON.parse(localStorage.getItem('user'));

    // If no user is logged in, redirect to the login page
    if (!user || !user.role) {
        return <Navigate to="/login" />;
    }

    // Convert the stored role to uppercase to make the check case-insensitive
    const userRole = user.role.toUpperCase();

    // Render the correct dashboard based on the user's role
    switch (userRole) {
        case 'PATIENT':
            return <PatientDashboard />;
        case 'DOCTOR':
            return <DoctorDashboard />;
        case 'HOSPITAL_ADMIN':
            return <AdminDashboard />;
        default:
            // If role is unknown, log it and redirect to login
            console.error("Unknown user role:", user.role);
            return <Navigate to="/login" />;
    }
}
