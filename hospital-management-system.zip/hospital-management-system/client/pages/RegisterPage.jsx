import React, { useState } from 'react';
import axios from 'axios';

export default function RegisterPage() {
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        fullName: '',
        role: 'PATIENT', // Default role
    });
    const [message, setMessage] = useState('');

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage(''); // Clear previous messages
        try {
            // The backend API endpoint we created
            const response = await axios.post('http://localhost:3001/api/auth/register', formData);
            setMessage(response.data.message); // Show success message from server
        } catch (error) {
            // Show error message from server
            setMessage(error.response?.data?.message || 'An error occurred.');
        }
    };

    return (
        <div className="form-container">
            <h2>Register New User</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value={formData.email} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Password</label>
                    <input type="password" name="password" value={formData.password} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Full Name</label>
                    <input type="text" name="fullName" value={formData.fullName} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Register as</label>
                    <select name="role" value={formData.role} onChange={handleChange}>
                        <option value="PATIENT">Patient</option>
                        <option value="DOCTOR">Doctor</option>
                        <option value="HOSPITAL_ADMIN">Hospital Admin</option>
                    </select>
                </div>
                <button type="submit">Register</button>
            </form>
            {message && <p className="message">{message}</p>}
        </div>
    );
}